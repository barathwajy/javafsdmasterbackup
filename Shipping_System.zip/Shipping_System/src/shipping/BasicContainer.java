package shipping;

public interface BasicContainer 
{
	int weightBC = 5000;
	String btype = "Basic";
	
	void basic();
	
		
	
}
	
	
	
	

