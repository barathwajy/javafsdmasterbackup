package shipping;

public interface HeavyContainer {
	int weightHC = 10000;
	String htype = "Heavy";
	
	void heavy();
}
