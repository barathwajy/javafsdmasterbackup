package shipping;

public interface RefrigeratedContainer{
	int weightRC = 10000;
	String rtype = "Cold";
	void refrigerated();
}
