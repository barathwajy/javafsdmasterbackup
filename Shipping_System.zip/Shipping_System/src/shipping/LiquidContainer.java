package shipping;

public interface LiquidContainer {
	int weightLC = 10000;
	String ltype = "Liquid";
	
	void liquid();
}
