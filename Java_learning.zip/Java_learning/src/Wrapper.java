import java.util.*;
public class Wrapper {
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		int n = s.nextInt();
		String name = s.next();
		System.out.println(n+name);
		s.close();
	}
	
}
