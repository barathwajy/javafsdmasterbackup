
//
public class Sample {
	static int a = 11;
	Sample()
	{
		System.out.println("k");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		
		int a =10;
		System.out.println(a);
		
		Sample s1 = new Sample();
		
		
		
		
	}

}
