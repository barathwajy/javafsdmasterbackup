
public class Datatypes {

	public static void main(String[] args)
	{
		boolean a1 = false;
		System.out.println(a1);
		
		int a2 = 1234567891;
		System.out.println(a2);

		byte a3 = 123;
		System.out.println(a3);
		
		short a4 = 12345;
		System.out.println(a4);
		
		long a5 = 1234567891234567891L;
		System.out.println(a1);
		
		char a6 = 'a';
		System.out.println(a6);
		
		float a7 = 12.7f;
		System.out.println(a7);
		
		double a8 = 90.9;
		System.out.println(a8);
		
		System.out.print(123 >> 2);
		
		
	}
}
