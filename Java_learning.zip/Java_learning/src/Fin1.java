
public class Fin1 {
	public static void main (String args[])
	{
		final int a =10;
		
	}
}
